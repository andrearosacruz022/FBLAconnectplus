import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_web_view.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'terms_and_conditions_page_widget.dart'
    show TermsAndConditionsPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TermsAndConditionsPageModel
    extends FlutterFlowModel<TermsAndConditionsPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
