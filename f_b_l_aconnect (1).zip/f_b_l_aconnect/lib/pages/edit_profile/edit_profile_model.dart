import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'edit_profile_widget.dart' show EditProfileWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EditProfileModel extends FlutterFlowModel<EditProfileWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for ChangeNameTextField widget.
  FocusNode? changeNameTextFieldFocusNode;
  TextEditingController? changeNameTextFieldTextController;
  String? Function(BuildContext, String?)?
      changeNameTextFieldTextControllerValidator;
  // State field(s) for ChangeBioTextField widget.
  FocusNode? changeBioTextFieldFocusNode;
  TextEditingController? changeBioTextFieldTextController;
  String? Function(BuildContext, String?)?
      changeBioTextFieldTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    changeNameTextFieldFocusNode?.dispose();
    changeNameTextFieldTextController?.dispose();

    changeBioTextFieldFocusNode?.dispose();
    changeBioTextFieldTextController?.dispose();
  }
}
