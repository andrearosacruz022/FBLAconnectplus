import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Calendar2Record extends FirestoreRecord {
  Calendar2Record._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "event_date" field.
  DateTime? _eventDate;
  DateTime? get eventDate => _eventDate;
  bool hasEventDate() => _eventDate != null;

  // "event_description" field.
  String? _eventDescription;
  String get eventDescription => _eventDescription ?? '';
  bool hasEventDescription() => _eventDescription != null;

  // "event_name" field.
  String? _eventName;
  String get eventName => _eventName ?? '';
  bool hasEventName() => _eventName != null;

  // "event_location" field.
  String? _eventLocation;
  String get eventLocation => _eventLocation ?? '';
  bool hasEventLocation() => _eventLocation != null;

  // "reminder" field.
  int? _reminder;
  int get reminder => _reminder ?? 0;
  bool hasReminder() => _reminder != null;

  // "user_ref" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  void _initializeFields() {
    _eventDate = snapshotData['event_date'] as DateTime?;
    _eventDescription = snapshotData['event_description'] as String?;
    _eventName = snapshotData['event_name'] as String?;
    _eventLocation = snapshotData['event_location'] as String?;
    _reminder = castToType<int>(snapshotData['reminder']);
    _userRef = snapshotData['user_ref'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('calendar2');

  static Stream<Calendar2Record> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => Calendar2Record.fromSnapshot(s));

  static Future<Calendar2Record> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => Calendar2Record.fromSnapshot(s));

  static Calendar2Record fromSnapshot(DocumentSnapshot snapshot) =>
      Calendar2Record._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static Calendar2Record getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      Calendar2Record._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'Calendar2Record(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is Calendar2Record &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCalendar2RecordData({
  DateTime? eventDate,
  String? eventDescription,
  String? eventName,
  String? eventLocation,
  int? reminder,
  DocumentReference? userRef,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'event_date': eventDate,
      'event_description': eventDescription,
      'event_name': eventName,
      'event_location': eventLocation,
      'reminder': reminder,
      'user_ref': userRef,
    }.withoutNulls,
  );

  return firestoreData;
}

class Calendar2RecordDocumentEquality implements Equality<Calendar2Record> {
  const Calendar2RecordDocumentEquality();

  @override
  bool equals(Calendar2Record? e1, Calendar2Record? e2) {
    return e1?.eventDate == e2?.eventDate &&
        e1?.eventDescription == e2?.eventDescription &&
        e1?.eventName == e2?.eventName &&
        e1?.eventLocation == e2?.eventLocation &&
        e1?.reminder == e2?.reminder &&
        e1?.userRef == e2?.userRef;
  }

  @override
  int hash(Calendar2Record? e) => const ListEquality().hash([
        e?.eventDate,
        e?.eventDescription,
        e?.eventName,
        e?.eventLocation,
        e?.reminder,
        e?.userRef
      ]);

  @override
  bool isValidKey(Object? o) => o is Calendar2Record;
}
